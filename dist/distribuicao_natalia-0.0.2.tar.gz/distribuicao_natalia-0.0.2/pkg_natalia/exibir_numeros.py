def naturaisImpares():
    for i in range(1, 100):
        if (i % 2 != 0):
            print ("Numeros naturais impares de 0 a 100:", i)

naturaisImpares()

def naturais():
    for i in range(1, 51):
        print ("Numeros naturais de 0 a 50: ", i)

naturais()
